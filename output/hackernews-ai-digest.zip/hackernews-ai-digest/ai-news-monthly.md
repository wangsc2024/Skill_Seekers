# Hacker News AI 新闻精选 - 2025年12月至2026年1月

> 更新时间：2026-01-08
> 来源：[Hacker News](https://news.ycombinator.com/)
> 筛选条件：AI / ML / LLM 相关
> 时间范围：近一个月

---

## 1. 2025 年 LLM 年度回顾

**原标题**: 2025: The Year in LLMs

**摘要**: 讨论了 AI 产业的商业价值。用户愿意每月支付 200 美元订阅 AI 服务，部分公司已获得 10 亿美元级别融资。评论认为"很难反驳当前 AI 的价值"。

**热度**: 🔥 热门讨论 | 📅 2 天前

**HN 讨论**: [Hacker News #46449643](https://news.ycombinator.com/item?id=46449643)

---

## 2. AI 的现状 - 2025 年 12 月

**原标题**: The state of AI – December 2025

**摘要**: 一篇捕捉"我们作为一个物种正在孕育这种新智能形式的荒谬之处"的文章。讨论了 AI 发展的当前阶段和未来展望。

**热度**: 🔥 热门讨论 | 📅 1 周内

**HN 讨论**: [Hacker News #46432907](https://news.ycombinator.com/item?id=46432907)

---

## 3. 2025 年底 AI 反思

**原标题**: Reflections on AI at the End of 2025

**摘要**: 讨论了公众对 LLM 的信任问题。家人使用 AI 询问医疗建议和人生建议的情况"越来越令人担忧"——幻觉问题仍然每天发生，但输出"如此令人信服，以至于人们难以不信任它们"。

**热度**: 🔥 热门讨论 | 📅 1 周前

**HN 讨论**: [Hacker News #46334819](https://news.ycombinator.com/item?id=46334819)

---

## 4. 2025 年机器学习/AI/数据全景图

**原标题**: Bubble and Build: The 2025 Mad (Machine Learning, AI and Data) Landscape

**摘要**: 对 2025 年 ML/AI/数据领域的全面分析，涵盖泡沫与建设并存的行业现状。

**热度**: 🔥 热门讨论 | 📅 1 周内

**HN 讨论**: [Hacker News #46368063](https://news.ycombinator.com/item?id=46368063)

---

## 5. 本地编程模型指南

**原标题**: A guide to local coding models

**摘要**: 讨论定价对比——"OpenAI 和 Anthropic 的 20 美元/月计划可以走很远"，并且"Codex 的收费比 Claude 低很多"。探讨了本地运行 AI 编程模型的实践方案。

**热度**: 🔥 热门讨论 | 📅 1 周前

**HN 讨论**: [Hacker News #46348329](https://news.ycombinator.com/item?id=46348329)

---

## 6. LLM 年度回顾：Claude Code 获好评

**原标题**: LLM Year in Review

**摘要**: 用户盛赞 Claude Code，表示"Claude 生成的代码几乎和我自己写的一模一样"，可以"90% 到 95% 地猜到它的代码会是什么样子，但它写得快得多"。

**热度**: 🔥 热门讨论 | 📅 3 周前

**HN 讨论**: [Hacker News #46330726](https://news.ycombinator.com/item?id=46330726)

---

## 7. GPT-5.2 发布讨论

**原标题**: GPT-5.2

**摘要**: 讨论认为"现在能产生最大差异的不是'更多智能'……而是更好的接地性"。探讨了模型能力提升的方向。

**热度**: 🔥 热门讨论 | 📅 约 3 周前

**HN 讨论**: [Hacker News #46234788](https://news.ycombinator.com/item?id=46234788)

---

## 8. AI 模型如何工作：无人完全了解

**原标题**: Like magic pixie dust, nobody knows in detail how AI models work

**摘要**: 讨论模型可解释性问题。有评论指出模型参数在 RAM 中，通过一些软件框架可以展示每一步的过程，但整体机制仍是"黑箱"。

**热度**: 🔥 热门讨论 | 📅 约 4 周前

**HN 讨论**: [Hacker News #46264882](https://news.ycombinator.com/item?id=46264882)

---

## 9. AI 寒冬要来了吗？

**原标题**: A new AI winter is coming?

**摘要**: 讨论认为"某些根本性的东西已经改变，使计算机能够相当有效地理解自然语言"，这是"互联网或谷歌搜索级别的发现"。短短两年内平台已有数十亿用户，化学、计算几何、生物学等领域正利用 AI 取得跨越式进展。

**热度**: 🔥 热门讨论 | 📅 2025-12-04

**HN 讨论**: [Hacker News #46109534](https://news.ycombinator.com/item?id=46109534)

---

## 10. DeepSeek-v3.2：推动开源大语言模型前沿

**原标题**: DeepSeek-v3.2: Pushing the frontier of open large language models

**摘要**: 讨论了运行 DeepSeek 模型的硬件基准测试，以及计算 tokens/秒来估算每 token 成本的方法。

**热度**: 🔥 热门讨论 | 📅 2025-12-04

**HN 讨论**: [Hacker News #46108780](https://news.ycombinator.com/item?id=46108780)

---

## 11. "AI 功能"只是语言模型的包装

**原标题**: A lot of shiny new "AI" features being shipped are language models being placed...

**摘要**: 讨论指出，即使在 LLM 大火之前，很多发表的机器学习研究使用的模型表现都不如最先进水平。举例：一篇使用"深度学习"预测余震的 Nature 论文，被另一篇仅使用一个神经元的论文超越。

**热度**: 🔥 热门讨论 | 📅 3 周前

**HN 讨论**: [Hacker News #46331577](https://news.ycombinator.com/item?id=46331577)

---

## 12. OpenAI 和 Anthropic 估值讨论

**原标题**: I literally cannot see how OpenAI and Anthropic can justify their valuation...

**摘要**: 用户讨论"DeepSeek 在价格上正在碾压"，同时提供可比的价值。评论认为"DeepSeek 只需提高价值，我就能看到他们摧毁 Anthropic，因为我认为编程是他们的主要关注点"。

**热度**: 🔥 热门讨论 | 📅 2025-01-29

**HN 讨论**: [Hacker News #42827214](https://news.ycombinator.com/item?id=42827214)

---

## 13. DeepSeek-R1 优于 Claude 3.5

**原标题**: For those who haven't realized it yet, Deepseek-R1 is better than claude 3.5...

**摘要**: 声称 DeepSeek-R1"就是更聪明"，并表示"Anthropic、OpenAI 和 Meta 正在恐慌。他们应该恐慌。门槛现在高多了"。

**热度**: 🔥 热门讨论 | 📅 2025-01-31

**HN 讨论**: [Hacker News #42828167](https://news.ycombinator.com/item?id=42828167)

---

## 14. OpenAI 称有证据表明 DeepSeek 使用其模型训练竞争对手

**原标题**: OpenAI says it has evidence DeepSeek used its model to train competitor

**摘要**: 讨论了"推理能力可以通过大规模强化学习 (RL) 显著提升，即使不使用监督微调"的技术细节。

**热度**: 🔥 热门讨论 | 📅 2025-02-04

**HN 讨论**: [Hacker News #42861475](https://news.ycombinator.com/item?id=42861475)

---

## 15. Claude 记忆功能

**原标题**: Claude Memory

**摘要**: Anthropic 推出的 Claude 记忆功能讨论，允许 AI 在对话之间保持上下文记忆。

**热度**: 🔥 热门讨论 | 📅 2025-10-27

**HN 讨论**: [Hacker News #45684134](https://news.ycombinator.com/item?id=45684134)

---

## 统计

| 指标 | 数值 |
|------|------|
| 新闻数量 | 15 |
| 时间范围 | 2025-12 至 2026-01 |
| 主要话题 | LLM 年度回顾、DeepSeek、Claude、GPT-5.2 |

## 热门话题分布

| 话题 | 数量 |
|------|------|
| LLM 年度回顾/趋势 | 5 |
| DeepSeek 相关 | 4 |
| Claude/Anthropic | 3 |
| GPT/OpenAI | 2 |
| AI 哲学讨论 | 1 |

## 关键趋势

1. **Claude Code 受开发者高度认可** - 代码质量被评价为"几乎和我自己写的一模一样"
2. **DeepSeek 崛起** - 在价格和性能上对 OpenAI/Anthropic 形成挑战
3. **AI 信任问题** - 公众使用 AI 做医疗/生活建议引发担忧
4. **商业化成熟** - 用户愿意支付 $200/月，证明 AI 价值
5. **开源模型进步** - DeepSeek-v3.2 推动开源 LLM 前沿

---

> 数据来源：Hacker News API + Web Search
> 生成工具：hackernews-ai-digest skill
